EXTERNAL MONKEY — paquete inicial

Contenido:
- index.html: interfaz web adaptable a móvil y PC.
- assets/cover.png: imagen de portada proporcionada.
- Acceso de demostración: key 12345.
- Menú: interruptor visual para Hologramas.

IMPORTANTE:
El interruptor de Hologramas es solo visual en esta versión. Para conectarlo
a una función real, hace falta el archivo o código que implementa esa función
y saber en qué plataforma/programa se ejecuta. Envíalo para integrar el control.

Para probar:
1. Extrae el ZIP.
2. Abre index.html en un navegador moderno.

La key está en el JavaScript del cliente; no es un sistema de autenticación seguro
para proteger contenido sensible.
